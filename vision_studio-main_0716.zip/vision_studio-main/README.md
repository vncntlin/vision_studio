**Team Name:** Vision Studio

**Project Name:** Visual-Based Voice Alert System for the Visually Impaired
